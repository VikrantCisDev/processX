import Home from './pages/homepage/Home.jsx'
import SignIn from './pages/sign-in/SignIn.jsx'

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Home />
      {/* <SignIn /> */}
    </div>
  )
}

export default App
